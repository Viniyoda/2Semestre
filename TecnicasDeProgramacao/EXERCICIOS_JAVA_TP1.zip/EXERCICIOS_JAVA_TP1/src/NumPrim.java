import java.util.Scanner;

public class NumPrim {

    public static boolean ehPrim(int num) {
        if (num <= 1) {
            return false;
        }
        for (int i = 2; i <= num / 2; i++) {
            if (num % i == 0) {
                return false;
            }
        }
        return true;
    }

    public static void main(String[]args) {

        Scanner input = new Scanner(System.in);
        System.out.print("Insira um numero: ");

        int num = input.nextInt();
        input.close();

        System.out.println("Numeros primos menores ou iguais a " + num + ":");
        for (int i = 2; i <= num; i++) {
            if (ehPrim(i)) {
                System.out.print(i + " ");
            }
        }
    }

}

import java.util.Scanner;

public class SeqFibonacci {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        System.out.print("Insira um numero: ");

        int num = input.nextInt();
        input.close();

        int x = 0;
        int y = 1;
        int z;

        System.out.println("Sequência de Fibonacci até o número " + num + ":");

        z = x + y;

        while (z <= num) {
            System.out.print(z + " ");
            x = y;
            y = z;
            z = x + y;
        }

    }

}

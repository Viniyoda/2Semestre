public class EncontrarMaiorMenor {
    public static void main(String[] args) {

        int menorNum = (Integer.MAX_VALUE);
        int maiorNum = 0;

        int numsInt[] = {10, 5, 7, 3, -1, 1, 3, 11, 20, 6, 9, 32, 46};

        for (int i = 0; i < numsInt.length; i++) {
            if (numsInt[i] > maiorNum) {
              maiorNum = numsInt[i];
            }
            if (numsInt[i] < menorNum) {
                menorNum = numsInt[i];
            }
        }

        System.out.println("Menor numero e: " + menorNum);
        System.out.println("Maior numero e: " + maiorNum);

    }
}

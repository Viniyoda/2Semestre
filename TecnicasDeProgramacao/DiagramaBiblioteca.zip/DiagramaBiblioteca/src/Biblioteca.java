import java.util.List;
import java.util.ArrayList;
import java.util.Date;

public class Biblioteca implements Pesquisar {
    private List<Livro> livros;
    private List<Emprestimo> emprestimos;

    public void realizarEmprestimo(Leitor leitor, Livro livro, Funcionario funcionario){
        if (livro.getQuantidadeDisponivel() > 0) {
            boolean hasPendingLoans = emprestimos.stream()
                    .anyMatch(e -> e.getLeitor().equals(leitor) && e.getDataDevolucao() == null);

            if (!hasPendingLoans) {
                livro.setQuantidadeDisponivel(livro.getQuantidadeDisponivel() - 1);
                Emprestimo emprestimo = new Emprestimo(leitor, livro, funcionario);
                emprestimos.add(emprestimo);
            } else {
                System.out.println("Leitor já possui empréstimos em aberto.");
            }
        } else {
            System.out.println("Livro não está disponível.");
        }
    }

    public void registrarDevolucao(Emprestimo emprestimo) {
        if (emprestimo.getDataDevolucao() == null) {
            emprestimo.setDataDevolucao(new Date());
            emprestimo.getLivro().setQuantidadeDisponivel(emprestimo.getLivro().getQuantidadeDisponivel() + 1);
        } else {
            System.out.println("Empréstimo já foi devolvido.");
        }
    }

    public List<Livro> listarLivrosDisponiveis() {
        List<Livro> disponiveis = new ArrayList<>();
        for (Livro livro : livros) {
            if (livro.getQuantidadeDisponivel() > 0) {
                disponiveis.add(livro);
            }
        }
        return disponiveis;
    }

    public List<Emprestimo> listarEmprestimosEmAberto() {
        List<Emprestimo> emAberto = new ArrayList<>();
        for (Emprestimo emprestimo : emprestimos) {
            if (emprestimo.getDataDevolucao() == null) {
                emAberto.add(emprestimo);
            }
        }
        return emAberto;
    }

    @Override
    public Livro pesquisarLivroPorTitulo(String titulo) {
        return livros.stream()
                .filter(livro -> livro.getTitulo().equalsIgnoreCase(titulo))
                .findFirst()
                .orElse(null);
    }

    @Override
    public Livro pesquisarLivroPorAutor(String nomeAutor) {
        List<Livro> resultado = new ArrayList<>();
        for (Livro livro : livros) {
            for (Autor autor : livro.getAutores()) {
                if (autor.getNome().equalsIgnoreCase(nomeAutor)) {
                    resultado.add(livro);
                    break;
                }
            }
        }
        return (Livro) resultado;
    }
}

public interface Pesquisar {
    Livro pesquisarLivroPorTitulo(String titulo);
    Livro pesquisarLivroPorAutor(String nomeAutor);
}

public class Teste {
    public static void main(String[] args) {

        double km = 2.8;
        double lt = 4.5;
        double mtcub = 2.5;
        double barril = 3.0;

        double metros = ConversaoDeDados.conv_KMpMT(km);
        double decilitros = ConversaoDeDados.conv_LTpDeciLT(lt);
        double pesCub = ConversaoDeDados.conv_MTCUBpPesCUB(mtcub);
        double decalitros = ConversaoDeDados.conv_BARRILpDecaLT(barril);
        double litros = ConversaoDeDados.conv_BARRILpLT(barril);

        System.out.println("2.8 quilômetros equivalem a " + metros + " metros.");
        System.out.println("4.5 litros equivalem a " + decilitros + " decilitros.");
        System.out.println("2.5 metros cúbicos equivalem a " + pesCub + " pés cúbicos.");
        System.out.println("3.0 barris equivalem a " + decalitros + " decalitros ou " + litros + " litros.");

    }
}

package Diagrama;

import java.util.Date;

public class Matricula {
    private Aluno aluno;
    private Turma turma;
    private Date dataMatricula;

    public Matricula(Aluno aluno, Date dataMatricula, Turma turma) {
        this.aluno = aluno;
        this.dataMatricula = dataMatricula;
        this.turma = turma;
    }

    public Aluno getAluno() {
        return aluno;
    }

    public void setAluno(Aluno aluno) {
        this.aluno = aluno;
    }

    public Turma getTurma() {
        return turma;
    }

    public void setTurma(Turma turma) {
        this.turma = turma;
    }

    public Date getDataMatricula() {
        return dataMatricula;
    }

    public void setDataMatricula(Date dataMatricula) {
        this.dataMatricula = dataMatricula;
    }
}

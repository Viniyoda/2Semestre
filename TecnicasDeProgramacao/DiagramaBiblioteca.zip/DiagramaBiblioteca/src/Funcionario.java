import java.util.Date;

public class Funcionario extends Pessoa{
    private String cargo;

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    public Funcionario(String nome, Date dataNascimento, String endereco, String telefone, String email, String cargo) {
        super(nome, dataNascimento, endereco, telefone, email);
        this.cargo = cargo;
    }
}

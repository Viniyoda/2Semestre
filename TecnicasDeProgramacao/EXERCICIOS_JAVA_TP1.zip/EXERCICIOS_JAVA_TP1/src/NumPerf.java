import java.util.Scanner;

public class NumPerf {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        System.out.print("Insira um numero: ");

        int num = input.nextInt();
        input.close();

        int cont = 1;
        for (int i = 2; i <= num / 2; i++) {
            if (num % i == 0) {
                cont += i;
            }
        }

        if (cont == num) {
            System.out.println("O numero e perfeito");
        }
        else {
            System.out.println("O numero nao e perfeito");
        }

    }

}

public class ConversaoDeDados {
    public static double conv_KMpMT(double km){
        return km * 1000;
    }
    public static double conv_LTpDeciLT(double lt){
        return lt * 10;
    }
    public static double conv_MTCUBpPesCUB(double mtcub){
        return mtcub * 35.31;
    }
    public static double conv_BARRILpDecaLT(double barril){
        return barril * 16.36;
    }
    public static double conv_BARRILpLT(double barril){
        return barril * 163.65;
    }
}

package Diagrama;

import java.util.Date;

public class Main {
    public static void main(String[] args) {
        // Criação dos objetos de alunos
        Aluno maria = new Aluno("Maria Souza", new Date(), "Rua A, 123", "2024001");
        Aluno pedro = new Aluno("Pedro Santos", new Date(), "Rua B, 456", "2024002");
        Aluno jose = new Aluno("José Amaral", new Date(), "Rua C, 789", "2024003");

        // Criação dos objetos de professores
        Professor professorJoao = new Professor("Professor João", new Date(), "Rua D, 101", "PR123");
        Professor professorAna = new Professor("Professora Ana", new Date(), "Rua E, 202", "PR456");

        // Criação dos objetos de disciplinas
        Disciplina matematica = new Disciplina("Matemática", 60, professorJoao);
        Disciplina portugues = new Disciplina("Português", 60, professorAna);

        // Associações dos professores às disciplinas
        matematica.setProfessor(professorJoao);
        portugues.setProfessor(professorAna);

        // Criação dos objetos de turmas
        Turma turmaA = new Turma("TURMA-A", 2024, professorJoao, matematica);
        Turma turmaB = new Turma("TURMA-B", 2024, professorAna, portugues);

        // Associações dos professores e disciplinas às turmas
        turmaA.setProfessor(professorJoao);
        turmaA.setDisciplina(matematica);
        turmaB.setProfessor(professorAna);
        turmaB.setDisciplina(portugues);

        // Criação dos objetos Secretaria e DiarioDeClasse
        Secretaria secretaria = new Secretaria();
        DiarioDeClasse diarioDeClasse = new DiarioDeClasse();

        // Matrícula dos alunos nas turmas
        secretaria.matricular(maria, turmaA);
        secretaria.matricular(pedro, turmaA);
        secretaria.matricular(jose, turmaB);

        // Registro de notas e frequências
        diarioDeClasse.registrarNota(maria, matematica, 9.5);
        diarioDeClasse.registrarNota(pedro, matematica, 7.0);
        diarioDeClasse.registrarNota(jose, portugues, 6.0);

        diarioDeClasse.registrarFrequencia(maria, matematica, true);
        diarioDeClasse.registrarFrequencia(pedro, matematica, false);
        diarioDeClasse.registrarFrequencia(jose, portugues, true);

        // Exibição dos resultados
        // Listar alunos matriculados na turma A
        System.out.println("Alunos matriculados na turma " + turmaA.getCodigo() + ":");
        for (Aluno aluno : turmaA.getAlunosMatriculados()) {
            System.out.println("- " + aluno.getNome() + " (Matrícula: " + aluno.getMatricula() + ")");
        }

        // Listar alunos matriculados na turma B
        System.out.println("Alunos matriculados na turma " + turmaB.getCodigo() + ":");
        for (Aluno aluno : turmaB.getAlunosMatriculados()) {
            System.out.println("- " + aluno.getNome() + " (Matrícula: " + aluno.getMatricula() + ")");
        }

        // Notas dos alunos
        System.out.println("\nNotas do aluno Maria Souza em Matemática:");
        for (Nota nota : diarioDeClasse.getNotas(maria, matematica)) {
            System.out.println("- " + nota.getValor());
        }

        System.out.println("\nNotas do aluno Pedro Santos em Matemática:");
        for (Nota nota : diarioDeClasse.getNotas(pedro, matematica)) {
            System.out.println("- " + nota.getValor());
        }

        System.out.println("\nNotas do aluno José Amaral em Português:");
        for (Nota nota : diarioDeClasse.getNotas(jose, portugues)) {
            System.out.println("- " + nota.getValor());
        }

        // Frequências dos alunos
        System.out.println("\nFrequência do aluno Maria Souza em Matemática:");
        for (Frequencia frequencia : diarioDeClasse.getFrequencias(maria, matematica)) {
            System.out.println("- " + (frequencia.isPresente() ? "Presente" : "Ausente"));
        }

        System.out.println("\nFrequência do aluno Pedro Santos em Matemática:");
        for (Frequencia frequencia : diarioDeClasse.getFrequencias(pedro, matematica)) {
            System.out.println("- " + (frequencia.isPresente() ? "Presente" : "Ausente"));
        }

        System.out.println("\nFrequência do aluno José Amaral em Português:");
        for (Frequencia frequencia : diarioDeClasse.getFrequencias(jose, portugues)) {
            System.out.println("- " + (frequencia.isPresente() ? "Presente" : "Ausente"));
        }
    }
}

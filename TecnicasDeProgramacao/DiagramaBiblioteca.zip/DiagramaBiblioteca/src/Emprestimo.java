import java.util.Date;

public class Emprestimo {
    private Leitor leitor;
    private Livro livro;
    private Date dataEmprestimo;
    private Date dataDevolucao;
    private Funcionario funcionario;

    public Leitor getLeitor() {
        return leitor;
    }

    public void setLeitor(Leitor leitor) {
        this.leitor = leitor;
    }

    public Livro getLivro() {
        return livro;
    }

    public void setLivro(Livro livro) {
        this.livro = livro;
    }

    public Date getDataEmprestimo() {
        return dataEmprestimo;
    }

    public void setDataEmprestimo(Date dataEmprestimo) {
        this.dataEmprestimo = dataEmprestimo;
    }

    public Date getDataDevolucao() {
        return dataDevolucao;
    }

    public void setDataDevolucao(Date dataDevolucao) {
        this.dataDevolucao = dataDevolucao;
    }

    public Funcionario getFuncionario() {
        return funcionario;
    }

    public void setFuncionario(Funcionario funcionario) {
        this.funcionario = funcionario;
    }

    public Emprestimo(Leitor leitor, Livro livro, Funcionario funcionario) {
        this.leitor = leitor;
        this.livro = livro;
        this.funcionario = funcionario;
    }
}

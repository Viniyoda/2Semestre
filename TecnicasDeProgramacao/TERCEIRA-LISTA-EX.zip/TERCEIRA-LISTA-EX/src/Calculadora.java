public class Calculadora {

    public static int somar(int a, int b) {return a + b;}

    public static int subtrair(int a, int b) {return a - b;}

    public static int multiplicar(int a, int b) {return a * b;}

    public static int divir(int a, int b) {return a / b;}

}

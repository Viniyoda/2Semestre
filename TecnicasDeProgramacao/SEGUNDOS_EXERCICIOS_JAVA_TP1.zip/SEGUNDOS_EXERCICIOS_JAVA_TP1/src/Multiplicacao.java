import java.util.Scanner;
public class Multiplicacao {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        System.out.println("Digite o primeiro número: ");
        double num1 = input.nextDouble();

        System.out.println("Digite o segundo número: ");
        double num2 = input.nextDouble();

        double resultado = num1 * num2;

        System.out.println("O resultado final e: " + resultado);
    }
}

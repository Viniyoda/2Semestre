import java.util.Scanner;

public class TesteCalculadora {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        System.out.println("Digite o primeiro número: ");
        int a = input.nextInt();
        System.out.println("Digite o segundo número: ");
        int b = input.nextInt();

        System.out.println("A soma dos números é: " + Calculadora.somar(a,b));
        System.out.println("A subtração dos números é: " + Calculadora.subtrair(a,b));
        System.out.println("A multiplicação dos números é: " + Calculadora.multiplicar(a,b));
        System.out.println("A divisão dos números é: " + Calculadora.divir(a,b));

    }
}

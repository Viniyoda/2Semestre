package Diagrama;

public class Frequencia {
    private Aluno aluno;
    private Disciplina disciplina;
    private boolean presente;

    public Frequencia(Aluno aluno, Disciplina disciplina, boolean presente) {
        this.aluno = aluno;
        this.disciplina = disciplina;
        this.presente = presente;
    }

    public Aluno getAluno() {
        return aluno;
    }

    public void setAluno(Aluno aluno) {
        this.aluno = aluno;
    }

    public Disciplina getDisciplina() {
        return disciplina;
    }

    public void setDisciplina(Disciplina disciplina) {
        this.disciplina = disciplina;
    }

    public boolean isPresente() {
        return presente;
    }

    public void setPresente(boolean presente) {
        this.presente = presente;
    }
}

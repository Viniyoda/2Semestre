import java.util.Scanner;

public class Tabuada {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        System.out.print("Insira um numero: ");

        int num = input.nextInt();
        input.close();

        for (int i = 1; i <= 10 ; i++) {
            int result = num * i;
            System.out.println(num + " * " + i + " = " + result);
        }

    }

}

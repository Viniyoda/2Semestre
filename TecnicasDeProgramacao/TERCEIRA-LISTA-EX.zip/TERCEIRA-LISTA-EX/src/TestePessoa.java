public class TestePessoa {
    public static void main(String[] args) {

        Pessoa pessoa = new Pessoa();

        pessoa.inicializar("Vinicius", "de Paula", 21, "123.456.789-10");

        System.out.println("Nome: " + pessoa.getNome());
        System.out.println("Sobrenome: " + pessoa.getSobrenome());
        System.out.println("Idade: " + pessoa.getIdade());
        System.out.println("CPF: " + pessoa.getCpf());

        pessoa.setNome("Viniyoda");

        System.out.println("Novo nome: " + pessoa.getNome());
    }
}

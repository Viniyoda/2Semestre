public class TesteLivro {
    public static void main(String[] args) {
        // Criando um livro
        Livro livro = new Livro();

        // Inicializando os atributos do livro
        livro.inicializar("Hobbit", "J.R.R. Tolkien", 1937, "Fantasia", "Editora HarperCollins");

        // Imprimindo os dados do livro
        System.out.println("Título: " + livro.getTitulo());
        System.out.println("Autor: " + livro.getAutor());
        System.out.println("Ano de Publicação: " + livro.getAnoPublicacao());
        System.out.println("Gênero: " + livro.getGenero());
        System.out.println("Editora: " + livro.getEditora());

        // Modificando o título do livro
        livro.setTitulo("O Hobbit");

        // Imprimindo o novo título do livro
        System.out.println("Novo Título: " + livro.getTitulo());
    }
}

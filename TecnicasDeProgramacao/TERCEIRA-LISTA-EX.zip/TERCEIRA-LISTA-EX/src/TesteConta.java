public class TesteConta {
    public static void main(String[] args) {

        Conta conta1 = new Conta(142);
        Conta conta2 = new Conta(360);

        conta1.depositar(1500);

        conta1.transferir(500, conta2);

        System.out.println("Saldo da conta 1: R$" + conta1.getSaldo());
        System.out.println("Saldo da conta 2: R$" + conta2.getSaldo());

        conta2.sacar(150);

        System.out.println("Saldo da conta 2 após saque: R$" + conta2.getSaldo());
    }
}

package Diagrama;

import java.util.Date;

public class Aluno extends Pessoa {
    private String matricula;

    public Aluno(String nome, Date dataNascimento, String endereco, String matricula) {
        super(dataNascimento, endereco, nome);
        this.matricula = matricula;
    }

    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }
}

package Diagrama;

import java.util.ArrayList;
import java.util.List;

public class DiarioDeClasse implements Avaliacao {
    private List<Nota> notas = new ArrayList<>();
    private List<Frequencia> frequencias = new ArrayList<>();

    public void registrarFrequencia(Aluno aluno, Disciplina disciplina, boolean presente) {
        Frequencia novaFrequencia = new Frequencia(aluno, disciplina, presente);
        frequencias.add(novaFrequencia);
    }

    public void registrarNota(Aluno aluno, Disciplina disciplina, double nota) {
        Nota novaNota = new Nota(aluno, disciplina, nota);
        notas.add(novaNota);
    }

    public List<Frequencia> getFrequencias(Aluno aluno, Disciplina disciplina) {
        List<Frequencia> frequenciasAluno = new ArrayList<>();
        for (Frequencia frequencia : frequencias) {
            if (frequencia.getAluno() == aluno && frequencia.getDisciplina() == disciplina) {
                frequenciasAluno.add(frequencia);
            }
        }
        return frequenciasAluno;
    }

    public List<Nota> getNotas(Aluno aluno, Disciplina disciplina) {
        List<Nota> notasAluno = new ArrayList<>();
        for (Nota nota : notas) {
            if (nota.getAluno() == aluno && nota.getDisciplina() == disciplina) {
                notasAluno.add(nota);
            }
        }
        return notasAluno;
    }
}

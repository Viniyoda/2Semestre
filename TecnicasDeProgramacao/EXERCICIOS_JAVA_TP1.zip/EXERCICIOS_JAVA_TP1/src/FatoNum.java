import java.util.Scanner;

public class FatoNum {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        System.out.print("Insira um numero: ");

        int num = input.nextInt();
        input.close();

        long fatorial = 1;
        for (int i = 1; i <= num; i++) {
            fatorial =  fatorial * i;
        }

        System.out.println("O fatorial de " + num + " e: " + fatorial);

    }

}

import java.util.Scanner;

public class ParImpar {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        System.out.print("Insira um numero: ");

        int num = input.nextInt();
        input.close();

        if (num % 2 == 0) {
            System.out.println(num + " e um numero par");
        }
        else {
            System.out.println(num + " e um numero impar");
        }

    }

}

public class TesteProduto {
    public static void main(String[] args) {

        Produto produto = new Produto();

        produto.inicializar("Camiseta", "Camiseta preta 100% algodão", 49.99, 50);

        System.out.println("Nome: " + produto.getNome());
        System.out.println("Descrição: " + produto.getDescricao());
        System.out.println("Preço: R$" + produto.getPreco());
        System.out.println("Quantidade: " + produto.getQuantidade());

        produto.setPreco(44.99);

        // Imprimindo o novo preço do produto
        System.out.println("Novo Preço: R$" + produto.getPreco());
    }
}

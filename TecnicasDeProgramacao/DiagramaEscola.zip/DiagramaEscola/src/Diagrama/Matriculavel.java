package Diagrama;

public interface Matriculavel {
    void matricular(Aluno aluno, Turma turma);
    void cancelarMatricula(Aluno aluno, Turma turma);
}

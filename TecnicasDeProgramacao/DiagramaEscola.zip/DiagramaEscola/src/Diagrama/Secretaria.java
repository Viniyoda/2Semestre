package Diagrama;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Secretaria implements Matriculavel {
    private List<Matricula> matriculas = new ArrayList<>();

    public void matricular(Aluno aluno, Turma turma) {
        if (!turma.getAlunos().contains(aluno)) {
            turma.getAlunos().add(aluno);
            Matricula matricula = new Matricula(aluno, new Date(),turma);
            matriculas.add(matricula);
        } else {
            System.out.println("O aluno já está matriculado nesta turma.");
        }
    }

    public void cancelarMatricula(Aluno aluno, Turma turma) {
        if (turma.getAlunos().contains(aluno)) {
            turma.getAlunos().remove(aluno);
            matriculas.removeIf(matricula -> matricula.getAluno() == aluno && matricula.getTurma() == turma);
        } else {
            System.out.println("O aluno não está matriculado nesta turma.");
        }
    }

    public List<Matricula> getMatriculas() {
        return matriculas;
    }
}

package Diagrama;

import java.util.Date;

public class Professor extends Pessoa {
    private String registro;

    public Professor(String nome, Date dataNascimento, String endereco, String registro) {
        super(dataNascimento, endereco, nome);
        this.registro = registro;
    }

    public String getRegistro() {
        return registro;
    }

    public void setRegistro(String registro) {
        this.registro = registro;
    }
}

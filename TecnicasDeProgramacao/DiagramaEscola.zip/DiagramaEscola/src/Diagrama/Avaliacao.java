package Diagrama;

public interface Avaliacao {
    void registrarNota(Aluno aluno, Disciplina disciplina, double nota);
    void registrarFrequencia(Aluno aluno, Disciplina disciplina, boolean presente);
}

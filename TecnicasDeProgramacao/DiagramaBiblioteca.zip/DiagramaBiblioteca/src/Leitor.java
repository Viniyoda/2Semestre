import java.util.Date;

public class Leitor extends Pessoa {
    private String codigo;

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public Leitor(String nome, Date dataNascimento, String endereco, String telefone, String email, String codigo) {
        super(nome, dataNascimento, endereco, telefone, email);
        this.codigo = codigo;
    }
}
